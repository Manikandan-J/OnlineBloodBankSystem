package com.obbs.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "donor_table")
public class DonorEntity {
	
	

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;
		@Column(name = "donor_name")
		private String donorName;
		
		@Column(name = "contact_number")
		private double contactNumber;
		
		
		@Column(name = "state")
		private String state;
		@Column(name = "area")
		private String area;
		@Column(name = "pin_code")
		private int pinCode;
		@Column(name = "blood_group")
		private String bloodGroup;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getDonorName() {
			return donorName;
		}
		public void setDonorName(String donorName) {
			this.donorName = donorName;
		}
		public double getContactNumber() {
			return contactNumber;
		}
		public void setContactNumber(double contactNumber) {
			this.contactNumber = contactNumber;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getArea() {
			return area;
		}
		public void setArea(String area) {
			this.area = area;
		}
		public int getPinCode() {
			return pinCode;
		}
		public void setPinCode(int pinCode) {
			this.pinCode = pinCode;
		}
		public String getBloodGroup() {
			return bloodGroup;
		}
		public void setBloodGroup(String bloodGroup) {
			this.bloodGroup = bloodGroup;
		}
		
	}


	



