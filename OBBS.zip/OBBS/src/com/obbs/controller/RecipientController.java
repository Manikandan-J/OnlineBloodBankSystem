package com.obbs.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.exception.ApplicationException;
import com.obbs.model.BloodGroupPojo;
import com.obbs.model.DonorPojo;
import com.obbs.model.HospitalPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.StatesPojo;
import com.obbs.service.DonorService;
import com.obbs.service.RecipientService;
import com.obbs.service.UsersService;

@Controller//This Annotation specifies the Controllers
public class RecipientController {

	@Autowired
	RecipientService recipientService;//This is used to creating Object
	@Autowired
	UsersService usersService;
	public static Logger logger = Logger.getLogger("OBBS");

@RequestMapping(value = "/postBloodRequirement", method = RequestMethod.GET)
 //this is used to display the Blood Required by the recipient in Home Page.
	public ModelAndView postBloodRequirement(HttpServletRequest request, HttpServletResponse response) 
     {
        ModelAndView mav = null;
		HttpSession session = request.getSession(false);
		
		try 
		{
			if ((session.getAttribute("username")) != null) 
			{
			List<StatesPojo> allStates = usersService.getAllStates();
			List<BloodGroupPojo> allBloodGroups = usersService.getAllBloodGroups();
			List<HospitalPojo> allHospitals = recipientService.getAllHospitals();
			mav = new ModelAndView("PostBloodRequirement");
			mav.addObject("allHospitals", allHospitals);
			mav.addObject("allStates", allStates);
			mav.addObject("allBloodGroups", allBloodGroups);
			}
			else 
			{
				mav = new ModelAndView("Home");
			}
		} 
		catch (ApplicationException e) 
		{
			logger.error(e.getMessage());
			mav = new ModelAndView("Error");
			mav.addObject("message",e.getMessage());
		}
		return mav;
	}

@RequestMapping("/insertBloodRequirement")
//This method id used to Post Requirement of the recipient incase of donor is not Available
 public ModelAndView insertBloodRequirement(@ModelAttribute("command") PostBloodRequirementPojo requisterPojo,
		BindingResult result,HttpServletRequest request, HttpServletResponse response) 
  {
		int id, temp;
		ModelAndView mav = null;
		HttpSession session = request.getSession(false);
		try 
		{
			if ((session.getAttribute("username")) != null) 
			{
			  id = recipientService.insertBloodRequirement(requisterPojo);
              if (id == 1) 
              {
				temp = recipientService.insertBloodRequirementDB(requisterPojo);
				{
					if (temp == 1) 
					{
						System.out.println("Recipient Details Entered in database");
					} 
					else 
					{
						System.out.println("Sorry not Entered");
					}

				}
				mav = new ModelAndView("PostedInHome");
			 }
			 else 
			 {
				mav = new ModelAndView("Error");
			 }
		   }
			else {
			mav = new ModelAndView("Home");
		     }
		}
		catch (ApplicationException e) 
		{
            logger.error(e.getMessage());
			mav = new ModelAndView("Error");
			mav.addObject("message",e.getMessage());
		}

		return mav;
}

@RequestMapping(value = "/recipientRequests", method = RequestMethod.GET)

   public ModelAndView recipientRequests(@ModelAttribute("recipient") RecipientPojo recipientPojo,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) 
     {
		ModelAndView mav = new ModelAndView();
		
		HttpSession session = request.getSession(false);
		List<DonorPojo> details = new ArrayList<DonorPojo>();
		try 
		{
			if ((session.getAttribute("username")) != null) 
			{
                details = recipientService.donorCheck(recipientPojo);
                if (!details.isEmpty()) 
                {
					mav = new ModelAndView("DonorDetails");
					mav.addObject("details", details);
				}
                else 
                {
                    List<StatesPojo> allStates = usersService.getAllStates();
					List<BloodGroupPojo> allBloodGroups = usersService.getAllBloodGroups();
                    System.out.println("controller:" + allStates);
					System.out.println("controller:" + allBloodGroups);
					mav = new ModelAndView("SearchDonor");
                    mav.addObject("donornotfound", "No donor found.Click here to post your requirement");
					mav.addObject("allStates", allStates);
					mav.addObject("allBloodGroups", allBloodGroups);
                 }
            }
			else 
			{
				mav = new ModelAndView("Home");
			}
       }
	   catch (Exception e) 
		{
			logger.error(e.getMessage());
			mav = new ModelAndView("Error");
			mav.addObject("message",e.getMessage());
		}
		return mav;
     }

}
