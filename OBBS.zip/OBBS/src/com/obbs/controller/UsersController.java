package com.obbs.controller;



import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.service.UsersService;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;

@Controller
public class UsersController {

	@Autowired
	UsersService usersService;
	
	@RequestMapping("/registerUsers")
	
	public ModelAndView addUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {		
		int id;	
		id = usersService.registerUser(usersPojo);
		if (id==1) {
			return new ModelAndView("Success");
		} else {
			return new ModelAndView("Error");
		}
		
	}
	@RequestMapping("/login")
	
	public ModelAndView loginUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {		
		int login;	
		login = usersService.loginUser(usersPojo);
		if (login==1)
		{
			return new ModelAndView("Success");
		} 
		else
		{
			return new ModelAndView("Error");
		}
		
	}
@RequestMapping("/donorLogin")
	
	public ModelAndView donorLogin(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response) {		
		int donorId;	
		donorId = usersService.donorLogin(donorPojo);
		System.out.println(donorId);
		if (donorId!=0)
		{
			request.setAttribute("donorId",donorId);	
			List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
			requirementList = usersService.displayRequirements();
			
			//model.put("studList", studList);
			request.setAttribute("requirementList",requirementList);
			System.out.println(requirementList);
			
			if (requirementList != null) {
				return new ModelAndView("DonorBooking");
			} else
				return new ModelAndView("Error");
		} 
		else
		{
			return new ModelAndView("Error");
		}
		
	}
@RequestMapping("/donorRequests")
	
	public ModelAndView donorRequests(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result) {		
		int id;	
		id = usersService.registerDonor(donorPojo);
		if (id==1) {
			return new ModelAndView("Success");
		} else {
			return new ModelAndView("Error");
		}
		
	}
@RequestMapping("/insertBloodRequirement")

public ModelAndView insertBloodRequirement(@ModelAttribute("command") PostBloodRequirementPojo requisterPojo, BindingResult result) {		
	int id;	
	System.out.println(requisterPojo.getRequisterName());
	id = usersService.insertBloodRequirement(requisterPojo);
	if (id==1) {
		return new ModelAndView("Success");
	} else {
		return new ModelAndView("Error");
	}
	
}
@RequestMapping("/requirementFetch")
public ModelAndView displayBloodRequirements(HttpServletRequest request, HttpServletResponse response) {
	System.out.println("555555");
	List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
	requirementList = usersService.displayRequirements();
	
	//model.put("studList", studList);
	request.setAttribute("requirementList",requirementList);
	if (requirementList != null) {
		return new ModelAndView("BloodRequired");
	} else
		return new ModelAndView("Error");
}
@RequestMapping("/slotBooking")
public ModelAndView slotBooking(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response)
{		
	    System.out.println(87958);
	    int i=slotBookingPojo.getDonorId();
	    System.out.println(i);
	    ModelAndView model=new ModelAndView("BookingForm");
		model.addObject("slotBookingPojo", slotBookingPojo);
	  return model;
	
}


@RequestMapping("/confirmSlot")
public ModelAndView confirmSlot(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response)
{	int recipientId,delete;	
System.out.println(slotBookingPojo.getDate());
recipientId = usersService.confirmSlot(slotBookingPojo);
if (recipientId!=0) {
	delete=usersService.deleteRequirement(recipientId);
	if(delete!=0)
	{
	 return new ModelAndView("Success");
	}
	
	else 
	{
		return new ModelAndView("Error");
	}
	
} else {
	return new ModelAndView("Error");
}

}
	


}
