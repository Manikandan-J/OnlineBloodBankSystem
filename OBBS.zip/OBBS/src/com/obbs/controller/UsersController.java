package com.obbs.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.service.UsersService;
import com.obbs.model.DonorPojo;
import com.obbs.model.UsersPojo;

@Controller
public class UsersController {

	@Autowired
	UsersService usersService;
	
	@RequestMapping("/registerUsers")
	
	public ModelAndView addUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {		
		int id;	
		id = usersService.registerUser(usersPojo);
		if (id==1) {
			return new ModelAndView("Success");
		} else {
			return new ModelAndView("Error");
		}
		
	}
	@RequestMapping("/login")
	
	public ModelAndView loginUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {		
		int login;	
		login = usersService.loginUser(usersPojo);
		if (login==1)
		{
			return new ModelAndView("Success");
		} 
		else
		{
			return new ModelAndView("Error");
		}
		
	}
@RequestMapping("/donorRequests")
	
	public ModelAndView donorRequests(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result) {		
		int id;	
		id = usersService.registerDonor(donorPojo);
		if (id==1) {
			return new ModelAndView("Success");
		} else {
			return new ModelAndView("Error");
		}
		
	}
	


}
