package com.obbs.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.service.UsersService;
import com.obbs.exception.ApplicationException;
import com.obbs.model.BloodGroupPojo;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.StatesPojo;
import com.obbs.model.UsersPojo;

@Controller
public class UsersController {

	@Autowired
	UsersService usersService;
	
	public static Logger logger = Logger.getLogger("OBBS");

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav=null;
		try {
			List<StatesPojo> allStates = usersService.getAllStates();
			List<BloodGroupPojo> allBloodGroups = usersService.getAllBloodGroups();
			
			mav =  new ModelAndView("Register");
			mav.addObject("allStates",allStates);
			mav.addObject("allBloodGroups",allBloodGroups);
			
		} catch (ApplicationException e) {
			logger.error(e);
			mav =  new ModelAndView("Error");
		}
		return mav;
	}

	@RequestMapping(value = "/loginUser", method = RequestMethod.GET)
	public ModelAndView loginUser(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("LoginUser");
	}

	@RequestMapping(value="/registerUsers", method = RequestMethod.POST)

	public ModelAndView addUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {
		int id;
		ModelAndView mav=null;
		try {
			id = usersService.registerUser(usersPojo);
		
	       

			 mav = new ModelAndView("LoginUser");
	        mav.addObject("message","Successfully Registered  you can login now "); 
			if (id == 1) {
				return mav;
			} else {
				return new ModelAndView("Error");
			}


		} catch (ApplicationException e) {
			logger.error(e);
			mav =  new ModelAndView("Error");
			
		}
		return mav;
		

	}

	@RequestMapping(value="/recipientLogin", method = RequestMethod.POST)

	public ModelAndView login(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response) {
		int login;
		ModelAndView mav= null;
		
		try {
			login = usersService.loginUser(usersPojo);
			
			if (login == 1) {
				HttpSession session = request.getSession();
				List<StatesPojo> allStates = usersService.getAllStates();
				List<BloodGroupPojo> allBloodGroups = usersService.getAllBloodGroups();
				mav=new ModelAndView("SearchDonor");
				mav.addObject("allStates",allStates);
				mav.addObject("allBloodGroups",allBloodGroups);
			}else {
				mav=new ModelAndView("LoginUser");
				mav.addObject("message", "Incorrect credentials,Try again with correct username and password");
				}
		} catch (ApplicationException e) {
			logger.error(e);
			mav=new ModelAndView("Error");
		}

		return mav;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public ModelAndView logoutPage(@RequestParam(value = "logout", required = false) String logout,
			HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		if (logout != null) {
			HttpSession session = request.getSession(false);
			session.invalidate();
			model.addObject("message", "Logged out successfully.");

		}

		return new ModelAndView("Home");
	}

	@RequestMapping("/requirementFetch")
	public ModelAndView displayBloodRequirements(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav =null;
		List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
		try {
			requirementList = usersService.displayRequirements();
			
			
			if (requirementList != null) {
			 mav=new ModelAndView("BloodRequired");
			 mav.addObject("requirementList",requirementList);
			}
		else
		{
			return new ModelAndView("Error");
		}

		} catch (ApplicationException e) {
			logger.error(e);
			mav=new ModelAndView("Error");
		}

		return mav;
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView home(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("Home");
	}

}
