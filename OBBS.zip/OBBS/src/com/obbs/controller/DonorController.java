package com.obbs.controller;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.exception.ApplicationException;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.service.DonorService;

@Controller
public class DonorController {
	@Autowired
	DonorService donorService;
	public static Logger logger = Logger.getLogger("OBBS");

	@RequestMapping(value="/donorLogin", method = RequestMethod.POST)

	public ModelAndView donorLogin(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int donorId;
		try {
			donorId = donorService.donorLogin(donorPojo);
			if (donorId != 0) {
				request.setAttribute("donorId", donorId);
				List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
				try {
					requirementList = donorService.displayRequirements();
					
					ModelAndView mav = new ModelAndView("DonorBooking");
					mav.addObject("requirementList", requirementList);

					if (requirementList != null) {
						return mav;
					} else
						return new ModelAndView("Error");
				} catch (ApplicationException e) {
					logger.error(e);
				}
			}
		} catch (ApplicationException e) {
			logger.error(e);

		}

		return new ModelAndView("Error");

	}

	@RequestMapping(value="/donorRequests",  method = RequestMethod.POST)

	public ModelAndView donorRequests(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result) {
		int id;
		try {
			id = donorService.registerDonor(donorPojo);
			if (id == 1) {
				return new ModelAndView("DonorLogin");
			}
		} catch (ApplicationException e) {

			logger.error(e);

		}
		return new ModelAndView("Error");

	}

	@RequestMapping(value="/slotBooking", method = RequestMethod.POST)
	public ModelAndView slotBooking(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {

		int i = slotBookingPojo.getDonorId();
		System.out.println(i);
		ModelAndView model = new ModelAndView("BookingForm");
		model.addObject("slotBookingPojo", slotBookingPojo);
		return model;

	}

	@RequestMapping(value="/confirmSlot", method = RequestMethod.POST)
	public ModelAndView confirmSlot(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int recipientId, delete;
		
		try {
			recipientId = donorService.confirmSlot(slotBookingPojo);
			if (recipientId != 0) {
				delete = donorService.deleteRequirement(recipientId);
				if (delete != 0) {
					return new ModelAndView("PostedInHome");
				}

				else {
					return new ModelAndView("Error");
				}

			}
		} catch (ApplicationException e) {
			logger.error(e);

		}
		return new ModelAndView("Error");

	}

	@RequestMapping(value = "/donorSignIn", method = RequestMethod.GET)
	public ModelAndView donorSignIn(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("DonorLogin");
	}

	@RequestMapping(value = "/donorRegister", method = RequestMethod.GET)
	public ModelAndView donorRegister(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("Donor");
	}
	@RequestMapping(value = "/donorLogout", method = RequestMethod.GET)
	public ModelAndView donorLogout(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("Home");
	}

}
