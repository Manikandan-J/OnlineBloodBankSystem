package com.obbs.controller;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.exception.ApplicationException;
import com.obbs.model.BloodGroupPojo;
import com.obbs.model.DonorPojo;
import com.obbs.model.FeedbackPojo;
import com.obbs.model.HospitalPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.StatesPojo;
import com.obbs.service.DonorService;
import com.obbs.service.RecipientService;
import com.obbs.service.UsersService;

@Controller
public class DonorController {
	@Autowired
	DonorService donorService;
	@Autowired
	UsersService usersService;
	@Autowired
	RecipientService recipientService;
	public static Logger logger = Logger.getLogger("OBBS");

	@RequestMapping(value="/donorLogin", method = RequestMethod.POST)

	public ModelAndView donorLogin(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int donorId;
		ModelAndView mav =null;
		try {
			donorId = donorService.donorLogin(donorPojo);
			if (donorId != 0) {
				request.setAttribute("donorId", donorId);
				
				List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
				try {
					requirementList = donorService.displayRequirements();
					
					
				

					if (requirementList != null) {
						mav=new ModelAndView("DonorBooking");
						mav.addObject("requirementList", requirementList);
					}
				} catch (ApplicationException e) {
					logger.error(e);
				}
			}
			 else
			 {		
				 mav= new ModelAndView("DonorLogin");
				mav.addObject("invalid", "Invalid credentials.Please try again!");
		}
		}
			catch (ApplicationException e) {
			logger.error(e);

		}

		return mav;

	}
	

	@RequestMapping(value="/donorRequests",  method = RequestMethod.POST)

	public ModelAndView donorRequests(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result) {
		int id;
		ModelAndView mav =null;
		try {
			id = donorService.registerDonor(donorPojo);
			if (id == 1) {
				
				mav = new ModelAndView("DonorLogin");
				mav.addObject("d_msg","Successfully registered as a donor"); 
				
			} else {
				
				mav = new ModelAndView("DonorRegister");
				mav.addObject("d_msg","Fill the missed fields"); 
				//return new ModelAndView("DonorRegister");
				
			}

		} catch (ApplicationException e) {

			logger.error(e);
			mav= new ModelAndView("Error");

		}
		
return mav;
	}

	@RequestMapping(value="/slotBooking", method = RequestMethod.POST)
	public ModelAndView slotBooking(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {

		int i = slotBookingPojo.getDonorId();
		System.out.println(i);
		ModelAndView model = new ModelAndView("BookingForm");
		model.addObject("slotBookingPojo", slotBookingPojo);
		return model;

	}

	@RequestMapping(value="/confirmSlot", method = RequestMethod.POST)
	public ModelAndView confirmSlot(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int recipientId, delete;
		ModelAndView mav =null;
		try {
			recipientId = donorService.confirmSlot(slotBookingPojo);
			if (recipientId != 0) {
				delete = donorService.deleteRequirement(recipientId);
				if (delete != 0) {
					mav= new ModelAndView("SlotConfirmation");
				}

				else {
					mav=new ModelAndView("Error");
				}

			}
		} catch (ApplicationException e) {
			logger.error(e);
			mav=new ModelAndView("Error");

		}
		return mav;

	}
	@RequestMapping("/feedback")

	public ModelAndView feedback(@ModelAttribute("command") FeedbackPojo feedbackPojo, BindingResult result) {
		int id;
		id = donorService.feedbackEntry(feedbackPojo);
		if (id == 1) {
			return new ModelAndView("Home");
		} else {
			return new ModelAndView("Error");
		}

	}
	@RequestMapping("/feedbackFetch")

	public ModelAndView feedbackFetch(@ModelAttribute("feedback") FeedbackPojo feedbackPojo,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) {
ModelAndView mav=null;
		List<FeedbackPojo> details = new ArrayList<FeedbackPojo>();
		details = donorService.feedbackFetch(feedbackPojo);
	
mav=new ModelAndView("FeedbackDetails");
		if (!details.isEmpty()) {
			mav.addObject("details", details);
			
		} else {
			mav.addObject("message","No feedback");
			
		}
return mav;
	}


	@RequestMapping(value = "/donorSignIn", method = RequestMethod.GET)
	public ModelAndView donorSignIn(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("DonorLogin");
	}

	@RequestMapping(value = "/donorRegister", method = RequestMethod.GET)
	public ModelAndView donorRegister(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav=null;
		try {
			List<StatesPojo> allStates = usersService.getAllStates();
			List<BloodGroupPojo> allBloodGroups = usersService.getAllBloodGroups();
			mav =  new ModelAndView("Donor");
			mav.addObject("allStates",allStates);
			mav.addObject("allBloodGroups",allBloodGroups);
		} catch (ApplicationException e) {
			logger.error(e);
			mav =  new ModelAndView("Error");
		}
		
		
		
		return mav;
	}
	@RequestMapping(value = "/donorLogout", method = RequestMethod.GET)
	public ModelAndView donorLogout(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("Home");
	}
	@RequestMapping(value = "/feedbackPage", method = RequestMethod.GET)
	public ModelAndView feedbackPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav=null;
		List<HospitalPojo> allHospitals;
		try {
			allHospitals = recipientService.getAllHospitals();
			mav =  new ModelAndView("Feedback");
			mav.addObject("allHospitals",allHospitals);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return mav;
	}


}
