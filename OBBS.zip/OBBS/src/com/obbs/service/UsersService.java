package com.obbs.service;

import com.obbs.model.DonorPojo;
import com.obbs.model.UsersPojo;


public interface UsersService {

	public int registerUser(UsersPojo usersPojo);

	public int loginUser(UsersPojo usersPojo);

	public int registerDonor(DonorPojo donorPojo);

	
}
