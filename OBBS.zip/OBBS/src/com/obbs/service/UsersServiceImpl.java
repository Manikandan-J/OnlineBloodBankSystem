package com.obbs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obbs.dao.UsersDao;
import com.obbs.model.DonorPojo;
import com.obbs.model.UsersPojo;

@Service("usersService")
public class UsersServiceImpl implements UsersService{

	@Autowired
	UsersDao usersDao;
	
	@Override
	public int registerUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		return usersDao.registerUser(usersPojo);
	}

	@Override
	public int loginUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		return usersDao.loginUser(usersPojo);
	}

	@Override
	public int registerDonor(DonorPojo donorPojo) {
		// TODO Auto-generated method stub
		return usersDao.registerDonor(donorPojo);
	}

	
}
