package com.obbs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.obbs.dao.UsersDao;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;

@Service("usersService")
public class UsersServiceImpl implements UsersService{

	@Autowired
	UsersDao usersDao;
	
	@Override
	public int registerUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		return usersDao.registerUser(usersPojo);
	}

	@Override
	public int loginUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		return usersDao.loginUser(usersPojo);
	}

	@Override
	public int registerDonor(DonorPojo donorPojo) {
		// TODO Auto-generated method stub
		return usersDao.registerDonor(donorPojo);
	}

	@Override
	public int insertBloodRequirement(PostBloodRequirementPojo requisterPojo) {
		// TODO Auto-generated method stub
		return usersDao.insertBloodRequirement(requisterPojo);
	}

	@Override
	public List<PostBloodRequirementPojo> displayRequirements() {
		// TODO Auto-generated method stub
		return usersDao.displayRequirements();
	}

	public int donorLogin(DonorPojo donorPojo) {
		return usersDao.donorLogin(donorPojo);
	}


	@Override
	public int confirmSlot(SlotBookingPojo slotBookingPojo) {
	
		return usersDao.confirmSlot(slotBookingPojo);
	}

	@Override
	public int deleteRequirement(int recipientId) {
		
		return usersDao.deleteRequirement(recipientId);
	}



	
}
