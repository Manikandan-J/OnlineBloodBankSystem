package com.obbs.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.obbs.entity.BloodRequirementEntity;
import com.obbs.entity.DonorEntity;
import com.obbs.exception.ApplicationException;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.RecipientPojo;

@Repository("recipientDao")
public class RecipientDaoImpl implements RecipientDao {
	@Override
	public int insertBloodRequirement(PostBloodRequirementPojo requisterPojo) throws ApplicationException {
		// TODO Auto-generated method stub
		
				SessionFactory sessionfactory = null;
				Session session = null;

				

				try {
					sessionfactory = HibernateUtil.getSessionFactory();
					session = sessionfactory.openSession();
					Transaction transaction = session.beginTransaction();
					
					//long contactNumber;
					

					BloodRequirementEntity requisterEntity = new BloodRequirementEntity();
					
					requisterEntity.setRequisterName(requisterPojo.getRequisterName());
					System.out.println(requisterPojo.getRequisterName());
					//contactNumber=(requisterPojo.getContactNumber());
					requisterEntity.setContactNumber(requisterPojo.getContactNumber());
					requisterEntity.setState(requisterPojo.getState());
					requisterEntity.setArea(requisterPojo.getArea());
					requisterEntity.setPinCode(requisterPojo.getPinCode());
					requisterEntity.setBloodGroup(requisterPojo.getBloodGroup());
					requisterEntity.setHospitalName(requisterPojo.getHospitalName());
					
					

					session.save(requisterEntity);
					transaction.commit();
				
				} catch (Exception e) {
					throw new ApplicationException(e.getMessage());
				}
				finally {
					session.close();
				}
				return 1;
	}
	
	@Override
	public List donorCheck(RecipientPojo recipientPojo) throws ApplicationException {
		SessionFactory sessionfactory = null;
		Session session = null;

		List<DonorPojo> details = null;
		details = new ArrayList<DonorPojo>();
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			List list = session.createQuery("from DonorEntity").list();

			for (int i = 0; i < list.size(); i++) {

				DonorEntity donorEntity = (DonorEntity) list.get(i);
				DonorPojo donorPojo = new DonorPojo();

				if (recipientPojo.getArea().equals(donorEntity.getArea())
						&& (recipientPojo.getBloodGroup().equals(donorEntity.getBloodGroup()))) {

					donorPojo.setId(donorEntity.getId());
					donorPojo.setDonorName(donorEntity.getDonorName());
					donorPojo.setArea(donorEntity.getArea());
					donorPojo.setBloodGroup(donorEntity.getBloodGroup());
					donorPojo.setContactNumber(donorEntity.getContactNumber());
					donorPojo.setPinCode(donorEntity.getPinCode());
					donorPojo.setState(donorEntity.getState());
					details.add(donorPojo);

				}

			}
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		finally {
			session.close();
		}

		return details;

	}

}
