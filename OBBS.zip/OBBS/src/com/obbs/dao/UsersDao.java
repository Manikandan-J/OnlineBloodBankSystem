package com.obbs.dao;

import java.util.List;

import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;

public interface UsersDao {

	public int registerUser(UsersPojo usersPojo);

	public int loginUser(UsersPojo usersPojo);

	public int registerDonor(DonorPojo donorPojo);

	public int insertBloodRequirement(PostBloodRequirementPojo requisterPojo);

	public List<PostBloodRequirementPojo> displayRequirements();

	public int donorLogin(DonorPojo donorPojo);

	

	public int confirmSlot(SlotBookingPojo slotBookingPojo);

	public int deleteRequirement(int recipientId);

	
}
