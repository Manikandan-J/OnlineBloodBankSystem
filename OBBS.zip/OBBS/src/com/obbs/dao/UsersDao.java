package com.obbs.dao;

import java.util.List;

import com.obbs.exception.ApplicationException;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;

public interface UsersDao {

	public int registerUser(UsersPojo usersPojo) throws ApplicationException;

	public int loginUser(UsersPojo usersPojo) throws ApplicationException;

	


	

	public List<PostBloodRequirementPojo> displayRequirements() throws ApplicationException;

	

	
}
