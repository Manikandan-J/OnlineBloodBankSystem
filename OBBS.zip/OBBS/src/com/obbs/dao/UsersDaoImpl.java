package com.obbs.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.obbs.entity.BloodRequirementEntity;
import com.obbs.entity.DonorEntity;
import com.obbs.entity.SlotBookingEntity;
import com.obbs.entity.UsersEntity;
import com.obbs.exception.ApplicationException;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;

@Repository("usersDao")
public class UsersDaoImpl implements UsersDao{

	@Override
	public int registerUser(UsersPojo usersPojo) throws ApplicationException {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			double contactNumber;

			UsersEntity usersEntity = new UsersEntity();
			System.out.println(usersPojo.getFirstName());
			
			usersEntity.setFirstName(usersPojo.getFirstName());
			usersEntity.setLastName(usersPojo.getLastName());
			usersEntity.setAge(usersPojo.getAge());
			usersEntity.setGender(usersPojo.getGender());
			contactNumber=(double)(usersPojo.getContactNumber());
			usersEntity.setContactNumber(contactNumber);
			
			usersEntity.setEmail(usersPojo.getEmail());
			usersEntity.setPassword(usersPojo.getPassword());
			usersEntity.setWeight(usersPojo.getWeight());
			usersEntity.setState(usersPojo.getState());
			usersEntity.setArea(usersPojo.getArea());
			usersEntity.setPinCode(usersPojo.getPinCode());
			usersEntity.setBloodGroup(usersPojo.getBloodGroup());
			

			session.save(usersEntity);
			transaction.commit();
		
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		finally {
			session.close();
		}
		return 1;
	}

	@Override
	public int loginUser(UsersPojo usersPojo) throws ApplicationException {
		
		SessionFactory sessionfactory = null;
		Session session = null;
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			
			List list = session.createQuery("from UsersEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				UsersEntity usersEntity = (UsersEntity) list.get(i);
				if(usersPojo.getEmail().equals(usersEntity.getEmail())&&(usersPojo.getPassword().equals(usersEntity.getPassword())))
				{
					return 1;
				}

				

			}

		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		finally {
			session.close();
		}
		return 0;
	}


	@Override
	public List<PostBloodRequirementPojo> displayRequirements() throws ApplicationException {
		System.out.println(594614);
		List<PostBloodRequirementPojo> displayList = null;
		SessionFactory sessionFactory = null;
		Session session = null;

		
		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			
			List list = session.createQuery("from BloodRequirementEntity").list();
			displayList = new ArrayList();
			
			

			for (int i = 0; i < list.size(); i++) {
				PostBloodRequirementPojo  requirementList= new PostBloodRequirementPojo();
				
				BloodRequirementEntity requirementEntity = (BloodRequirementEntity) list.get(i);
				
				requirementList.setRequisterName(requirementEntity.getRequisterName());
				requirementList.setArea(requirementEntity.getArea());
				requirementList.setId(requirementEntity.getId());
				requirementList.setBloodGroup(requirementEntity.getBloodGroup());
				System.out.println(requirementEntity.getBloodGroup());
				requirementList.setContactNumber(requirementEntity.getContactNumber());
				System.out.println(requirementEntity.getContactNumber());
				requirementList.setState(requirementEntity.getState());
				requirementList.setPinCode(requirementEntity.getPinCode());
				requirementList.setHospitalName(requirementEntity.getHospitalName());

				displayList.add(requirementList);

			}
		
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		finally {
			session.close();
		}
		return displayList;
		
	}

	
}


