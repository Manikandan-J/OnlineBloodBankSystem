package com.obbs.dao;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.obbs.entity.BloodRequirementEntity;
import com.obbs.entity.DonorEntity;
import com.obbs.entity.SlotBookingEntity;
import com.obbs.entity.UsersEntity;
import com.obbs.model.DonorPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;



@Repository("usersDao")
public class UsersDaoImpl implements UsersDao {

	@Override
	public int registerUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;

		

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			double contactNumber;
			

			UsersEntity usersEntity = new UsersEntity();
			System.out.println(usersPojo.getFirstName());
			
			usersEntity.setFirstName(usersPojo.getFirstName());
			usersEntity.setLastName(usersPojo.getLastName());
			usersEntity.setAge(usersPojo.getAge());
			usersEntity.setGender(usersPojo.getGender());
			contactNumber=(double)(usersPojo.getContactNumber());
			usersEntity.setContactNumber(contactNumber);
			
			usersEntity.setEmail(usersPojo.getEmail());
			usersEntity.setPassword(usersPojo.getPassword());
			usersEntity.setWeight(usersPojo.getWeight());
			usersEntity.setState(usersPojo.getState());
			usersEntity.setArea(usersPojo.getArea());
			usersEntity.setPinCode(usersPojo.getPinCode());
			usersEntity.setBloodGroup(usersPojo.getBloodGroup());
			

			session.save(usersEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int loginUser(UsersPojo usersPojo) {
		
		SessionFactory sessionfactory = null;
		Session session = null;
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			
			List list = session.createQuery("from UsersEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				UsersEntity usersEntity = (UsersEntity) list.get(i);
				if(usersPojo.getFirstName().equals(usersEntity.getFirstName())&&(usersPojo.getPassword().equals(usersEntity.getPassword())))
				{
					return 1;
				}

				

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}


	@Override
	public int registerDonor(DonorPojo donorPojo) {
		// TODO Auto-generated method stub
		
		SessionFactory sessionfactory = null;
		Session session = null;

		

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			long contactNumber;
			

			DonorEntity donorEntity = new DonorEntity();
			
			donorEntity.setDonorName(donorPojo.getDonorName());
			System.out.println(donorPojo.getDonorName());
			contactNumber=(donorPojo.getContactNumber());
			donorEntity.setContactNumber(contactNumber);
			donorEntity.setState(donorPojo.getState());
			donorEntity.setArea(donorPojo.getArea());
			donorEntity.setPinCode(donorPojo.getPinCode());
			donorEntity.setBloodGroup(donorPojo.getBloodGroup());
			donorEntity.setEmail(donorPojo.getEmail());
			donorEntity.setPassword(donorPojo.getPassword());
			
			
			

			session.save(donorEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int insertBloodRequirement(PostBloodRequirementPojo requisterPojo) {
		// TODO Auto-generated method stub
		
				SessionFactory sessionfactory = null;
				Session session = null;

				

				try {
					sessionfactory = HibernateUtil.getSessionFactory();
					session = sessionfactory.openSession();
					Transaction transaction = session.beginTransaction();
					
					//long contactNumber;
					

					BloodRequirementEntity requisterEntity = new BloodRequirementEntity();
					
					requisterEntity.setRequisterName(requisterPojo.getRequisterName());
					System.out.println(requisterPojo.getRequisterName());
					//contactNumber=(requisterPojo.getContactNumber());
					requisterEntity.setContactNumber(requisterPojo.getContactNumber());
					requisterEntity.setState(requisterPojo.getState());
					requisterEntity.setArea(requisterPojo.getArea());
					requisterEntity.setPinCode(requisterPojo.getPinCode());
					requisterEntity.setBloodGroup(requisterPojo.getBloodGroup());
					requisterEntity.setHospitalName(requisterPojo.getHospitalName());
					
					

					session.save(requisterEntity);
					transaction.commit();
					return 1;
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				return 0;
	}

	@Override
	public List<PostBloodRequirementPojo> displayRequirements() {
		System.out.println(594614);
		List<PostBloodRequirementPojo> displayList = null;
		SessionFactory sessionFactory = null;
		Session session = null;

		
		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			
			List list = session.createQuery("from BloodRequirementEntity").list();
			displayList = new ArrayList();
			
			

			for (int i = 0; i < list.size(); i++) {
				PostBloodRequirementPojo  requirementList= new PostBloodRequirementPojo();
				
				BloodRequirementEntity requirementEntity = (BloodRequirementEntity) list.get(i);
				
				requirementList.setRequisterName(requirementEntity.getRequisterName());
				requirementList.setArea(requirementEntity.getArea());
				requirementList.setId(requirementEntity.getId());
				requirementList.setBloodGroup(requirementEntity.getBloodGroup());
				System.out.println(requirementEntity.getBloodGroup());
				requirementList.setContactNumber(requirementEntity.getContactNumber());
				System.out.println(requirementEntity.getContactNumber());
				requirementList.setState(requirementEntity.getState());
				requirementList.setPinCode(requirementEntity.getPinCode());
				requirementList.setHospitalName(requirementEntity.getHospitalName());

				displayList.add(requirementList);

			}
			
			return displayList;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
		
	}

	public int donorLogin(DonorPojo donorPojo) {

		SessionFactory sessionfactory = null;
		Session session = null;
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			
			List list = session.createQuery("from DonorEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				DonorEntity donorEntity = (DonorEntity) list.get(i);
				if(donorPojo.getEmail().equals(donorEntity.getEmail())&&(donorPojo.getPassword().equals(donorEntity.getPassword())))
				{
					return donorEntity.getId();
				}

				

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	

	@Override
	public int confirmSlot(SlotBookingPojo slotBookingPojo) {
		SessionFactory sessionfactory = null;
		Session session = null;

		

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			
			

			SlotBookingEntity slotEntity = new SlotBookingEntity();
			
			slotEntity.setRecipientId(slotBookingPojo.getRecipientId());
			//System.out.println(slotBookingPojo.getRequisterName());
			//contactNumber=(requisterPojo.getContactNumber());
			slotEntity.setDonorId(slotBookingPojo.getDonorId());
			slotEntity.setHospitalName(slotBookingPojo.getHospitalName());
			slotEntity.setArea(slotBookingPojo.getArea());
			slotEntity.setDate(slotBookingPojo.getDate());
			slotEntity.setTimeSlot(slotBookingPojo.getTimeSlot());
			
			
			

			session.save(slotEntity);
			transaction.commit();
			return slotEntity.getRecipientId();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int deleteRequirement(int recipientId) {
		SessionFactory sessionfaFactory=null;
		Session session=null;
		try {
			sessionfaFactory = HibernateUtil.getSessionFactory();
			session =sessionfaFactory.openSession();
			Transaction transaction=session.beginTransaction();
			BloodRequirementEntity bloodRequirementEntity=new BloodRequirementEntity();
			bloodRequirementEntity.setId(recipientId);
			session.delete(bloodRequirementEntity);
			transaction.commit();
			return 1;
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return 0;
	}
}


