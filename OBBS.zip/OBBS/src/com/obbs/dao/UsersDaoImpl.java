package com.obbs.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.obbs.entity.DonorEntity;
import com.obbs.entity.UsersEntity;
import com.obbs.model.DonorPojo;
import com.obbs.model.UsersPojo;


@Repository("usersDao")
public class UsersDaoImpl implements UsersDao {

	@Override
	public int registerUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;

		

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			double contactNumber;
			

			UsersEntity usersEntity = new UsersEntity();
			System.out.println(usersPojo.getFirstName());
			
			usersEntity.setFirstName(usersPojo.getFirstName());
			usersEntity.setLastName(usersPojo.getLastName());
			usersEntity.setAge(usersPojo.getAge());
			usersEntity.setGender(usersPojo.getGender());
			contactNumber=(double)(usersPojo.getContactNumber());
			usersEntity.setContactNumber(contactNumber);
			
			usersEntity.setEmail(usersPojo.getEmail());
			usersEntity.setPassword(usersPojo.getPassword());
			usersEntity.setWeight(usersPojo.getWeight());
			usersEntity.setState(usersPojo.getState());
			usersEntity.setArea(usersPojo.getArea());
			usersEntity.setPinCode(usersPojo.getPinCode());
			usersEntity.setBloodGroup(usersPojo.getBloodGroup());
			

			session.save(usersEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int loginUser(UsersPojo usersPojo) {
		
		SessionFactory sessionfactory = null;
		Session session = null;
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			
			List list = session.createQuery("from UsersEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				UsersEntity usersEntity = (UsersEntity) list.get(i);
				if(usersPojo.getFirstName().equals(usersEntity.getFirstName())&&(usersPojo.getPassword().equals(usersEntity.getPassword())))
				{
					return 1;
				}

				

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int registerDonor(DonorPojo donorPojo) {
		// TODO Auto-generated method stub
		
		SessionFactory sessionfactory = null;
		Session session = null;

		

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			double contactNumber;
			

			DonorEntity donorEntity = new DonorEntity();
			
			donorEntity.setDonorName(donorPojo.getDonorName());
			System.out.println(donorPojo.getDonorName());
			contactNumber=(double)(donorPojo.getContactNumber());
			donorEntity.setContactNumber(contactNumber);
			donorEntity.setState(donorPojo.getState());
			donorEntity.setArea(donorPojo.getArea());
			donorEntity.setPinCode(donorPojo.getPinCode());
			donorEntity.setBloodGroup(donorPojo.getBloodGroup());
			
			
			

			session.save(donorEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}


}
