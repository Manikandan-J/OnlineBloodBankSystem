package com.obbs.model;
//This Pojo is used to store the Hospital data  during Operation. 
public class HospitalPojo {
	private int id;
	private String hospitalName;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

}
